import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  de: { translation: { "play": "Spiel Starten", "settings": "Einstellungen", "discord": "Discord beitreten", "back": "Zurück", "create_world": "Welt erstellen", "start": "Starten" } }
};

i18n.use(initReactI18next).init({ resources, lng: "de", fallbackLng: "de", interpolation: { escapeValue: false } });
export default i18n;
