import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';

export default function MainMenu({ onStart }: { onStart: (cfg: any) => void }) {
  const { t } = useTranslation();
  const [view, setView] = useState('main');

  return (
    <div className="w-full h-full flex flex-col items-center justify-center bg-blue-900 bg-cover bg-center">
      <div className="bg-black/60 p-8 rounded-lg text-center backdrop-blur-sm border-4 border-gray-600 w-full max-w-2xl">
        <h1 className="text-4xl text-yellow-400 mb-8 font-minecraft drop-shadow-lg">BoostLab Minecraft</h1>
        {view === 'main' && (
          <div className="flex flex-col gap-4 w-64 mx-auto">
            <button className="mc-btn" onClick={() => setView('create')}>{t('play')}</button>
            <a href="https://discord.gg/RfVsQcyUZp" target="_blank" rel="noreferrer" className="mc-btn text-blue-300">
              {t('discord')}
            </a>
          </div>
        )}
        {view === 'create' && (
          <div className="flex flex-col gap-4 w-64 mx-auto">
            <button className="mc-btn mt-6" onClick={() => onStart({ mode: 'creative' })}>Web-Welt Betreten</button>
            <button className="mc-btn mt-2" onClick={() => setView('main')}>{t('back')}</button>
          </div>
        )}
      </div>
    </div>
  );
}
