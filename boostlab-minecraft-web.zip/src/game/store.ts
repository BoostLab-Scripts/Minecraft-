import { create } from 'zustand';

// Block types mapping (simple colors for now to ensure it works without external assets failing)
export const BLOCK_TYPES = {
  1: { name: 'Dirt', color: '#5C4033' },
  2: { name: 'Grass', color: '#41980a' },
  3: { name: 'Stone', color: '#888888' },
  4: { name: 'Wood', color: '#654321' },
  5: { name: 'Leaves', color: '#2d5a27' },
  6: { name: 'Sand', color: '#C2B280' },
  7: { name: 'Glass', color: '#a8d5ff' },
  8: { name: 'Brick', color: '#B22222' },
  9: { name: 'Obsidian', color: '#1a1a1a' },
};

type GameState = {
  blocks: Record<string, number>; // "x,y,z" -> blockType
  addBlock: (x: number, y: number, z: number, type: number) => void;
  removeBlock: (x: number, y: number, z: number) => void;
  activeBlock: number;
  setActiveBlock: (type: number) => void;
};

export const useStore = create<GameState>((set) => ({
  blocks: {},
  addBlock: (x, y, z, type) => set((state) => ({ blocks: { ...state.blocks, [`${x},${y},${z}`]: type } })),
  removeBlock: (x, y, z) => set((state) => {
    const newBlocks = { ...state.blocks };
    delete newBlocks[`${x},${y},${z}`];
    return { blocks: newBlocks };
  }),
  activeBlock: 1,
  setActiveBlock: (type) => set({ activeBlock: type }),
}));
