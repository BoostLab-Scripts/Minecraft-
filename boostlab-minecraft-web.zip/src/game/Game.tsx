import React, { useEffect, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { Sky, PointerLockControls } from '@react-three/drei';
import Player from './Player';
import WorldChunks from './WorldChunks';
import UIOverlay from './UIOverlay';
import { useStore } from './store';

export default function Game({ config, onExit }: { config: any, onExit: () => void }) {
  const [locked, setLocked] = useState(false);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
       if(e.key === 'Escape') setLocked(false);
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  return (
    <>
      <Canvas shadows camera={{ fov: 75, position: [0, 20, 0] }}>
        <Sky sunPosition={[100, 20, 100]} />
        <ambientLight intensity={0.5} />
        <pointLight castShadow intensity={1} position={[100, 100, 100]} />
        
        <WorldChunks />
        <Player locked={locked} />
        
        <PointerLockControls 
           selector="#lock-btn" 
           onLock={() => setLocked(true)} 
           onUnlock={() => setLocked(false)} 
        />
      </Canvas>
      <UIOverlay config={config} locked={locked} onExit={onExit} />
    </>
  );
}
