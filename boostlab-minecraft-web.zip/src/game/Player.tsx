import { useFrame, useThree } from '@react-three/fiber';
import { useEffect, useRef } from 'react';
import { Vector3, Raycaster } from 'three';
import { useStore } from './store';

export default function Player({ locked }: { locked: boolean }) {
  const { camera, scene } = useThree();
  const velocity = useRef(new Vector3());
  const direction = useRef(new Vector3());
  const keys = useRef<{ [key: string]: boolean }>({});
  
  const addBlock = useStore(state => state.addBlock);
  const removeBlock = useStore(state => state.removeBlock);
  const activeBlock = useStore(state => state.activeBlock);
  const setActiveBlock = useStore(state => state.setActiveBlock);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
       keys.current[e.code] = true;
       // Hotbar keys
       if(e.key >= '1' && e.key <= '9') {
          setActiveBlock(parseInt(e.key));
       }
    };
    const onKeyUp = (e: KeyboardEvent) => { keys.current[e.code] = false; };
    
    const onMouseClick = (e: MouseEvent) => {
      if(!locked) return;
      const raycaster = new Raycaster();
      raycaster.setFromCamera({x: 0, y: 0}, camera);
      
      // Raycast against the instanced mesh (the world)
      const intersects = raycaster.intersectObjects(scene.children);
      if (intersects.length > 0) {
        const intersection = intersects.find(i => i.object.type === 'InstancedMesh');
        if(intersection && intersection.instanceId !== undefined) {
           // We need to calculate the block position based on face normal
           const pos = new Vector3().copy(intersection.point);
           const normal = intersection.face?.normal || new Vector3();
           
           if(e.button === 0) { // Left Click: Break
             pos.sub(normal.clone().multiplyScalar(0.5)); // push slightly in
             const x = Math.round(pos.x);
             const y = Math.round(pos.y);
             const z = Math.round(pos.z);
             removeBlock(x, y, z);
             addBlock(x, y, z, 0); // 0 acts as a delete marker in our system
           } else if (e.button === 2) { // Right Click: Place
             pos.add(normal.clone().multiplyScalar(0.5)); // push slightly out
             const x = Math.round(pos.x);
             const y = Math.round(pos.y);
             const z = Math.round(pos.z);
             addBlock(x, y, z, activeBlock);
           }
        }
      }
    };

    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('keyup', onKeyUp);
    document.addEventListener('mousedown', onMouseClick);
    
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.removeEventListener('keyup', onKeyUp);
      document.removeEventListener('mousedown', onMouseClick);
    };
  }, [locked, camera, scene, addBlock, removeBlock, activeBlock, setActiveBlock]);

  useFrame((_, delta) => {
    if (!locked) return;
    const speed = 25.0;
    
    velocity.current.x -= velocity.current.x * 10.0 * delta;
    velocity.current.z -= velocity.current.z * 10.0 * delta;
    velocity.current.y -= velocity.current.y * 10.0 * delta;

    direction.current.z = Number(keys.current['KeyW'] ? 1 : 0) - Number(keys.current['KeyS'] ? 1 : 0);
    direction.current.x = Number(keys.current['KeyD'] ? 1 : 0) - Number(keys.current['KeyA'] ? 1 : 0);
    direction.current.y = Number(keys.current['Space'] ? 1 : 0) - Number(keys.current['ShiftLeft'] ? 1 : 0);
    direction.current.normalize();

    if (keys.current['KeyW'] || keys.current['KeyS']) velocity.current.z -= direction.current.z * speed * delta;
    if (keys.current['KeyA'] || keys.current['KeyD']) velocity.current.x -= direction.current.x * speed * delta;
    if (keys.current['Space'] || keys.current['ShiftLeft']) velocity.current.y += direction.current.y * speed * delta;

    camera.translateX(-velocity.current.x);
    camera.translateZ(velocity.current.z);
    camera.position.y += velocity.current.y;
  });

  return null;
}
