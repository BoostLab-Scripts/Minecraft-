import React from 'react';
import { useStore, BLOCK_TYPES } from './store';

export default function UIOverlay({ config, locked, onExit }: { config: any, locked: boolean, onExit: () => void }) {
  const activeBlock = useStore(state => state.activeBlock);

  return (
    <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
      
      {/* Crosshair */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white text-2xl font-bold opacity-70">
        +
      </div>

      {/* Info */}
      <div className="absolute top-4 left-4 text-white text-xs bg-black/30 p-2">
        <p className="text-yellow-400 font-bold mb-1">BoostLab Web Edition</p>
        <p>Links-Klick: Abbauen</p>
        <p>Rechts-Klick: Platzieren</p>
        <p>Tasten 1-9: Block wählen</p>
        <p>W,A,S,D: Bewegen | Leertaste/Shift: Fliegen</p>
      </div>

      {/* Hotbar */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-1 bg-black/60 p-1 border-2 border-gray-600 rounded">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => {
          const bInfo = BLOCK_TYPES[num as keyof typeof BLOCK_TYPES];
          const isActive = activeBlock === num;
          return (
            <div 
              key={num} 
              className={`w-12 h-12 border-2 flex items-center justify-center text-[10px] text-white
                ${isActive ? 'border-yellow-400 bg-white/20' : 'border-gray-500 bg-gray-800'}`}
              style={{ backgroundColor: isActive ? undefined : bInfo?.color }}
            >
              <span className="bg-black/50 px-1 rounded">{num}</span>
            </div>
          );
        })}
      </div>

      {/* Pause Menu overlay */}
      {!locked && (
        <div className="absolute top-0 left-0 w-full h-full bg-black/50 pointer-events-auto flex items-center justify-center backdrop-blur-sm">
           <div className="flex flex-col gap-4">
              <h2 className="text-white text-2xl mb-4 text-center">Spiel Pausiert</h2>
              <button id="lock-btn" className="mc-btn text-xl py-4 px-8">Zurück ins Spiel</button>
              <button onClick={onExit} className="mc-btn py-2 text-gray-300">Menü</button>
           </div>
        </div>
      )}
    </div>
  );
}
