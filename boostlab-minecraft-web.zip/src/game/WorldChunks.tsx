import React, { useMemo, useRef, useState, useEffect } from 'react';
import { InstancedMesh, Matrix4, Color } from 'three';
import { useStore, BLOCK_TYPES } from './store';
import { createNoise2D } from 'simplex-noise';

// Custom component to handle instanced rendering of ALL blocks efficiently
export default function WorldChunks() {
  const meshRef = useRef<InstancedMesh>(null);
  const storeBlocks = useStore(state => state.blocks);
  
  // Generate initial terrain ONCE
  const initialTerrain = useMemo(() => {
    const noise2D = createNoise2D();
    const size = 32;
    const blocks: Record<string, number> = {};
    
    for (let x = -size/2; x < size/2; x++) {
      for (let z = -size/2; z < size/2; z++) {
        // Simple heightmap
        const height = Math.floor(noise2D(x * 0.05, z * 0.05) * 5) + 5;
        // Surface is grass (2), below is dirt (1), deep is stone (3)
        for(let y = 0; y <= height; y++) {
           let type = 3; // stone
           if(y === height) type = 2; // grass
           else if(y > height - 3) type = 1; // dirt
           
           blocks[`${x},${y},${z}`] = type;
        }
      }
    }
    return blocks;
  }, []);

  // Merge initial terrain with modifications from the store
  const allBlocks = useMemo(() => {
    const merged = { ...initialTerrain };
    // Apply additions and deletions
    for (const [key, type] of Object.entries(storeBlocks)) {
      if (type === 0) {
         delete merged[key]; // type 0 means deleted
      } else {
         merged[key] = type;
      }
    }
    return merged;
  }, [initialTerrain, storeBlocks]);

  useEffect(() => {
    if (!meshRef.current) return;
    
    const blockEntries = Object.entries(allBlocks);
    meshRef.current.count = blockEntries.length;
    
    const dummy = new Matrix4();
    const color = new Color();
    
    blockEntries.forEach(([key, type], i) => {
      const [x, y, z] = key.split(',').map(Number);
      dummy.setPosition(x, y, z);
      meshRef.current!.setMatrixAt(i, dummy);
      
      const blockData = BLOCK_TYPES[type as keyof typeof BLOCK_TYPES];
      if(blockData) {
        meshRef.current!.setColorAt(i, color.set(blockData.color));
      }
    });
    
    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
  }, [allBlocks]);

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, 50000]} castShadow receiveShadow>
      <boxGeometry args={[1, 1, 1]} />
      <meshLambertMaterial vertexColors />
    </instancedMesh>
  );
}
