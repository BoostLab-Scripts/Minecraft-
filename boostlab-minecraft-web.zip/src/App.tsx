import React, { useState } from 'react';
import MainMenu from './components/MainMenu';
import Game from './game/Game';

export default function App() {
  const [gameState, setGameState] = useState<'menu' | 'playing'>('menu');
  const [config, setConfig] = useState({ mode: 'survival' });

  if (gameState === 'menu') return <MainMenu onStart={(cfg) => { setConfig(cfg); setGameState('playing'); }} />;
  
  return (
    <div className="w-full h-full relative">
      <Game config={config} onExit={() => setGameState('menu')} />
    </div>
  );
}
